// src/app/api/arbs/route.ts
import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { createOddsApiProvider } from '@/lib/providers/theOddsApiProvider';
import { detectAllOpportunities } from '@/lib/arb/detector';
import { getCache } from '@/lib/cache';
import { config } from '@/lib/config';
import { getUserApiKey } from '@/lib/getUserApiKey';
import dbConnect from '@/lib/mongodb';
import User from '@/lib/models/User';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

const NO_STORE_HEADERS = {
  'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
  Pragma: 'no-cache',
};

export async function GET(request: Request) {
  try {
    // Check authentication
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json(
        { error: 'Authentication required. Please log in to scan for opportunities.' },
        { status: 401, headers: NO_STORE_HEADERS }
      );
    }

    // Check subscription status
    await dbConnect();
    const userId = (session.user as { id: string }).id;
    const user = await User.findById(userId);

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404, headers: NO_STORE_HEADERS }
      );
    }

    // Check if user has active subscription
    const hasActiveSubscription = 
      user.subscriptionStatus === 'active' && 
      user.subscriptionEndsAt !== undefined &&
      user.subscriptionEndsAt !== null &&
      new Date(user.subscriptionEndsAt) > new Date();

    if (!hasActiveSubscription) {
      return NextResponse.json(
        { 
          error: 'Active subscription required',
          subscriptionRequired: true,
          message: 'Please subscribe to access the arbitrage scanner.',
        },
        { status: 403, headers: NO_STORE_HEADERS }
      );
    }

    const { searchParams } = new URL(request.url);
    const minProfit = parseFloat(searchParams.get('minProfit') || '-2');
    const maxHours = parseInt(searchParams.get('maxHours') || '72', 10);
    const forceRefresh = searchParams.get('refresh') === 'true';
    const showNearArbs = searchParams.get('nearArbs') !== 'false';
    const showValueBets = searchParams.get('valueBets') !== 'false';
    
    // Get regions parameter (comma-separated API regions like 'au,uk,us,eu')
    // Defaults to 'au' for backwards compatibility
    const regions = searchParams.get('regions') || 'au';
    const isMultiRegion = regions.includes(',') || regions !== 'au';
    
    // Get sports filter (comma-separated sport keys for Quick Scan)
    const sportsFilter = searchParams.get('sports');
    const requestedSports = sportsFilter ? sportsFilter.split(',').map(s => s.trim()) : null;
    const isQuickScan = requestedSports !== null && requestedSports.length > 0;

    const cache = getCache();

    // Check cache first (only for single AU region with no sports filter)
    if (!forceRefresh && !isMultiRegion && !isQuickScan) {
      const cached = cache.getArbs();
      if (cached) {
        return NextResponse.json(
          {
            ...cached,
            cached: true,
            regions,
          },
          { headers: NO_STORE_HEADERS }
        );
      }
    }

    // Get user's API key from database
    const userApiKey = await getUserApiKey();
    
    // If no API key, return helpful message
    if (!userApiKey) {
      return NextResponse.json(
        {
        opportunities: [],
        valueBets: [],
        stats: {
          totalEvents: 0,
          eventsWithMultipleBookmakers: 0,
          totalBookmakers: 0,
          arbsFound: 0,
          nearArbsFound: 0,
          valueBetsFound: 0,
          sportsScanned: 0,
        },
        lastUpdated: new Date().toISOString(),
        isUsingMockData: false,
        cached: false,
        regions,
        noApiKey: true,
          message: 'No API key configured. Go to Settings to add your Odds API key.',
        },
        { headers: NO_STORE_HEADERS }
      );
    }

    // Create provider with user's key
    const provider = createOddsApiProvider(userApiKey);

    console.log(`[API /arbs] Using provider: ${provider.name}, regions: ${regions}${isQuickScan ? ', Quick Scan mode' : ''}`);

    // Fetch ALL available sports
    console.log('[API /arbs] Fetching available sports list...');
    const allSports = await provider.getSupportedSports();
    
    // Filter to sports with h2h markets (no outrights)
    let sportsToFetch = allSports
      .filter(s => !s.hasOutrights)
      .map(s => s.key);
    
    // Apply sports filter if Quick Scan is active
    if (isQuickScan) {
      const availableSportsSet = new Set(sportsToFetch);
      sportsToFetch = requestedSports.filter(sport => availableSportsSet.has(sport));
      console.log(`[API /arbs] Quick Scan: filtered to ${sportsToFetch.length} of ${requestedSports.length} requested sports`);
    }
    
    console.log(`[API /arbs] Found ${sportsToFetch.length} sports with h2h markets`);

    // Fetch odds - pass regions string
    console.log(`[API /arbs] Fetching odds for ${sportsToFetch.length} sports...`);
    const oddsResult = await provider.fetchOdds(sportsToFetch, ['h2h'], regions);

    console.log(`[API /arbs] Total events fetched: ${oddsResult.events.length}`);

    // Log bookmaker distribution
    const bookmakerCount = new Map<string, number>();
    oddsResult.events.forEach(e => {
      e.bookmakers.forEach(b => {
        bookmakerCount.set(b.bookmaker.key, (bookmakerCount.get(b.bookmaker.key) || 0) + 1);
      });
    });
    console.log(`[API /arbs] Bookmakers found:`, Object.fromEntries(bookmakerCount));

    // Update odds cache (only in single AU mode with full scan)
    if (!isMultiRegion && !isQuickScan) {
      cache.setOdds({
        events: oddsResult.events,
        source: oddsResult.meta.source,
        remainingRequests: oddsResult.meta.remainingRequests,
      });
    }

    // Detect all opportunities
    const { arbs, valueBets, stats } = detectAllOpportunities(
      oddsResult.events,
      config.filters.nearArbThreshold,
      config.filters.valueThreshold
    );

    console.log(`[API /arbs] Detection complete:`, stats);

    // Filter by time
    const now = new Date();
    const maxTime = new Date(now.getTime() + maxHours * 60 * 60 * 1000);

    const filteredArbs = arbs.filter(opp => {
      if (opp.profitPercentage < minProfit) return false;
      if (!showNearArbs && opp.type === 'near-arb') return false;
      if (opp.event.commenceTime > maxTime) return false;
      if (opp.event.commenceTime < now) return false;
      return true;
    });

    const filteredValueBets = showValueBets 
      ? valueBets.filter(vb => {
          if (vb.event.commenceTime > maxTime) return false;
          if (vb.event.commenceTime < now) return false;
          return true;
        })
      : [];

    const response = {
      opportunities: filteredArbs,
      valueBets: filteredValueBets,
      stats,
      lastUpdated: new Date().toISOString(),
      isUsingMockData: false,
      cached: false,
      regions,
      remainingApiRequests: oddsResult.meta.remainingRequests,
    };

    // Cache the response (only in single AU mode with full scan)
    if (!isMultiRegion && !isQuickScan) {
      cache.setArbs({
        opportunities: arbs,
        valueBets,
        isUsingMockData: false,
      });
    }

    return NextResponse.json(response, { headers: NO_STORE_HEADERS });
  } catch (error) {
    console.error('[API /arbs] Error:', error);
    return NextResponse.json(
      { error: 'Failed to compute opportunities', details: String(error) },
      { status: 500, headers: NO_STORE_HEADERS }
    );
  }
}
