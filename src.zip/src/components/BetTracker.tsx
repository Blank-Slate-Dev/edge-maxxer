// src/components/BetTracker.tsx
'use client';

import { useState } from 'react';
import { format } from 'date-fns';
import { Trash2, ChevronDown, ChevronUp, TrendingUp, DollarSign, Target, Percent, Calendar, Clock } from 'lucide-react';
import type { PlacedBet } from '@/lib/bets';
import { calculateBetStats } from '@/lib/bets';

interface BetTrackerProps {
  bets: PlacedBet[];
  onUpdateBet: (id: string, updates: Partial<PlacedBet>) => void;
  onDeleteBet: (id: string) => void;
  onClearAll: () => void;
}

// Format date in AEST
function formatEventTime(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleString('en-AU', {
    timeZone: 'Australia/Sydney',
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  });
}

// Format date shorter for mobile
function formatEventTimeShort(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleString('en-AU', {
    timeZone: 'Australia/Sydney',
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    hour: 'numeric',
    minute: '2-digit',
  });
}

// Check if event is in the past
function isEventPast(dateString: string): boolean {
  return new Date(dateString) < new Date();
}

// Check if event is starting soon (within 2 hours)
function isEventSoon(dateString: string): boolean {
  const eventTime = new Date(dateString);
  const now = new Date();
  const twoHours = 2 * 60 * 60 * 1000;
  return eventTime > now && eventTime.getTime() - now.getTime() < twoHours;
}

// Get mode badge
function ModeBadge({ mode }: { mode: PlacedBet['mode'] }) {
  const styles: Record<string, { bg: string; text: string; label: string }> = {
    'book-vs-book': { bg: 'bg-[var(--surface-secondary)]', text: 'text-[var(--muted)]', label: 'H2H' },
    'book-vs-betfair': { bg: 'bg-purple-900/50', text: 'text-purple-400', label: 'Betfair' },
    'value-bet': { bg: 'bg-blue-900/50', text: 'text-blue-400', label: 'Value' },
    'spread': { bg: 'bg-orange-900/50', text: 'text-orange-400', label: 'Spread' },
    'totals': { bg: 'bg-cyan-900/50', text: 'text-cyan-400', label: 'Totals' },
    'middle': { bg: 'bg-yellow-900/50', text: 'text-yellow-400', label: 'Middle' },
  };
  const style = styles[mode] || styles['book-vs-book'];
  
  return (
    <span className={`text-xs px-1.5 py-0.5 rounded ${style.bg} ${style.text}`}>
      {style.label}
    </span>
  );
}

export function BetTracker({ bets, onUpdateBet, onDeleteBet, onClearAll }: BetTrackerProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [showConfirmClear, setShowConfirmClear] = useState(false);
  const stats = calculateBetStats(bets);

  if (bets.length === 0) {
    return (
      <div 
        className="border rounded-lg"
        style={{
          borderColor: 'var(--border)',
          backgroundColor: 'var(--surface)'
        }}
      >
        <div className="px-4 sm:px-6 py-6 sm:py-8 text-center">
          <p style={{ color: 'var(--muted)' }} className="mb-2 text-sm">No bets logged yet</p>
          <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
            Use the calculator to log your bets and track performance
          </p>
        </div>
      </div>
    );
  }

  return (
    <div 
      className="border rounded-lg"
      style={{
        borderColor: 'var(--border)',
        backgroundColor: 'var(--surface)'
      }}
    >
      {/* Header */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full px-4 sm:px-6 py-3 sm:py-4 flex items-center justify-between text-left hover:bg-[var(--surface-hover)] transition-colors border-b"
        style={{ borderColor: 'var(--border)' }}
      >
        <div className="flex items-center gap-2 sm:gap-3">
          <span className="font-medium text-sm sm:text-base" style={{ color: 'var(--foreground)' }}>Bet History</span>
          <span 
            className="text-xs px-1.5 sm:px-2 py-0.5 rounded"
            style={{
              backgroundColor: 'var(--surface-secondary)',
              color: 'var(--muted)'
            }}
          >
            {bets.length}
          </span>
        </div>
        {isExpanded ? (
          <ChevronUp className="w-4 h-4" style={{ color: 'var(--muted)' }} />
        ) : (
          <ChevronDown className="w-4 h-4" style={{ color: 'var(--muted)' }} />
        )}
      </button>

      {isExpanded && (
        <>
          {/* Stats Grid */}
          <div 
            className="grid grid-cols-2 sm:grid-cols-4 gap-px border-b"
            style={{ 
              backgroundColor: 'var(--border)',
              borderColor: 'var(--border)'
            }}
          >
            <StatCard
              icon={<Target className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
              label="Total Bets"
              value={stats.totalBets.toString()}
            />
            <StatCard
              icon={<DollarSign className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
              label="Total Staked"
              value={`$${stats.totalStaked.toFixed(0)}`}
            />
            <StatCard
              icon={<TrendingUp className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
              label="Actual Profit"
              value={`$${stats.totalActualProfit.toFixed(2)}`}
              highlight={stats.totalActualProfit > 0}
              negative={stats.totalActualProfit < 0}
            />
            <StatCard
              icon={<Percent className="w-3.5 h-3.5 sm:w-4 sm:h-4" />}
              label="ROI"
              value={`${stats.roi.toFixed(1)}%`}
              highlight={stats.roi > 0}
              negative={stats.roi < 0}
            />
          </div>

          {/* Bet List */}
          <div 
            className="divide-y max-h-[60vh] sm:max-h-96 overflow-y-auto"
            style={{ borderColor: 'var(--border)' }}
          >
            {bets.map(bet => (
              <BetRow
                key={bet.id}
                bet={bet}
                onUpdate={updates => onUpdateBet(bet.id, updates)}
                onDelete={() => onDeleteBet(bet.id)}
              />
            ))}
          </div>

          {/* Footer Actions */}
          <div 
            className="px-4 sm:px-6 py-3 border-t flex justify-end"
            style={{ borderColor: 'var(--border)' }}
          >
            {showConfirmClear ? (
              <div className="flex items-center gap-2 sm:gap-3">
                <span className="text-xs" style={{ color: 'var(--muted)' }}>Clear all?</span>
                <button
                  onClick={() => {
                    onClearAll();
                    setShowConfirmClear(false);
                  }}
                  className="text-xs px-2 sm:px-3 py-1 transition-colors rounded"
                  style={{
                    backgroundColor: 'var(--foreground)',
                    color: 'var(--background)'
                  }}
                >
                  Yes
                </button>
                <button
                  onClick={() => setShowConfirmClear(false)}
                  className="text-xs px-2 sm:px-3 py-1 border transition-colors rounded"
                  style={{
                    borderColor: 'var(--border)',
                    color: 'var(--muted)'
                  }}
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                onClick={() => setShowConfirmClear(true)}
                className="text-xs transition-colors"
                style={{ color: 'var(--muted)' }}
              >
                Clear all
              </button>
            )}
          </div>
        </>
      )}
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  highlight,
  negative,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  highlight?: boolean;
  negative?: boolean;
}) {
  return (
    <div className="px-3 sm:px-4 py-2.5 sm:py-3" style={{ backgroundColor: 'var(--surface)' }}>
      <div className="flex items-center gap-1.5 sm:gap-2 mb-0.5 sm:mb-1" style={{ color: 'var(--muted)' }}>
        {icon}
        <span className="text-[10px] sm:text-xs uppercase tracking-wide">{label}</span>
      </div>
      <div 
        className="text-base sm:text-lg font-mono font-medium"
        style={{ 
          color: highlight 
            ? 'var(--success)' 
            : negative 
              ? 'var(--danger)' 
              : 'var(--muted)' 
        }}
      >
        {value}
      </div>
    </div>
  );
}

// Get all possible outcomes for a bet
function getBetOutcomes(bet: PlacedBet): { id: string; label: string; profit: number }[] {
  const outcomes: { id: string; label: string; profit: number }[] = [];
  
  // Value bet
  if (bet.mode === 'value-bet' && bet.bet1) {
    const totalStake = bet.bet1.stake;
    const winReturn = bet.bet1.stake * bet.bet1.odds;
    outcomes.push({ 
      id: 'won', 
      label: `${bet.bet1.outcome} won`, 
      profit: winReturn - totalStake 
    });
    outcomes.push({ 
      id: 'lost', 
      label: `${bet.bet1.outcome} lost`, 
      profit: -totalStake 
    });
  }
  // Middle bet
  else if (bet.mode === 'middle' && bet.bet1 && bet.bet2) {
    const totalStake = bet.bet1.stake + bet.bet2.stake;
    const bothWinReturn = (bet.bet1.stake * bet.bet1.odds) + (bet.bet2.stake * bet.bet2.odds);
    const side1WinReturn = bet.bet1.stake * bet.bet1.odds;
    const side2WinReturn = bet.bet2.stake * bet.bet2.odds;
    
    outcomes.push({
      id: 'middle_hit',
      label: `Middle hit! Both won`,
      profit: bothWinReturn - totalStake,
    });
    outcomes.push({
      id: 'side1_won',
      label: `${bet.bet1.outcome} won`,
      profit: side1WinReturn - totalStake,
    });
    outcomes.push({
      id: 'side2_won',
      label: `${bet.bet2.outcome} won`,
      profit: side2WinReturn - totalStake,
    });
  }
  // Spread/Totals/Book-vs-Book (2-way)
  else if ((bet.mode === 'book-vs-book' || bet.mode === 'spread' || bet.mode === 'totals') && bet.bet1 && bet.bet2) {
    const bets = [bet.bet1, bet.bet2];
    if (bet.bet3) bets.push(bet.bet3);
    
    const totalStake = bets.reduce((sum, b) => sum + b.stake, 0);
    
    bets.forEach((b, index) => {
      const returnAmount = b.stake * b.odds;
      outcomes.push({
        id: `outcome_${index}`,
        label: b.outcome,
        profit: returnAmount - totalStake,
      });
    });
  }
  // Book vs Betfair
  else if (bet.mode === 'book-vs-betfair' && bet.backBet && bet.layBet) {
    const totalStake = bet.backBet.stake + bet.layBet.liability;
    const backReturn = bet.backBet.stake * bet.backBet.odds;
    
    outcomes.push({
      id: 'back_won',
      label: `${bet.backBet.outcome} won`,
      profit: backReturn - totalStake,
    });
    outcomes.push({
      id: 'lay_won',
      label: `${bet.backBet.outcome} lost`,
      profit: bet.layBet.stake - bet.layBet.liability,
    });
  }
  
  return outcomes;
}

// Calculate profits for display
function calculateBetProfits(bet: PlacedBet): { 
  totalStake: number; 
  minProfit: number;
  maxProfit: number;
  isMiddle: boolean;
  isValueBet: boolean;
  middleProfit?: number;
} {
  // Value bet
  if (bet.mode === 'value-bet' && bet.bet1) {
    const totalStake = bet.bet1.stake;
    const potentialReturn = bet.bet1.stake * bet.bet1.odds;
    const winProfit = potentialReturn - totalStake;
    const loseProfit = -totalStake;
    
    return {
      totalStake,
      minProfit: loseProfit,
      maxProfit: winProfit,
      isMiddle: false,
      isValueBet: true,
    };
  }
  
  // Middle bet
  if (bet.mode === 'middle' && bet.bet1 && bet.bet2) {
    const totalStake = bet.bet1.stake + bet.bet2.stake;
    const bothWinReturn = (bet.bet1.stake * bet.bet1.odds) + (bet.bet2.stake * bet.bet2.odds);
    const side1WinReturn = bet.bet1.stake * bet.bet1.odds;
    const side2WinReturn = bet.bet2.stake * bet.bet2.odds;
    
    const middleProfit = bothWinReturn - totalStake;
    const missProfit = Math.max(side1WinReturn, side2WinReturn) - totalStake;
    
    return {
      totalStake,
      minProfit: missProfit,
      maxProfit: middleProfit,
      isMiddle: true,
      isValueBet: false,
      middleProfit,
    };
  }
  
  // Spread/Totals/Book-vs-Book
  if ((bet.mode === 'book-vs-book' || bet.mode === 'spread' || bet.mode === 'totals') && bet.bet1 && bet.bet2) {
    const bets = [bet.bet1, bet.bet2];
    if (bet.bet3) bets.push(bet.bet3);
    
    const totalStake = bets.reduce((sum, b) => sum + b.stake, 0);
    const returns = bets.map(b => b.stake * b.odds);
    const profits = returns.map(r => r - totalStake);
    
    return {
      totalStake,
      minProfit: Math.min(...profits),
      maxProfit: Math.max(...profits),
      isMiddle: false,
      isValueBet: false,
    };
  }
  
  // Book vs Betfair
  if (bet.backBet && bet.layBet) {
    const totalStake = bet.backBet.stake + bet.layBet.liability;
    const backReturn = bet.backBet.stake * bet.backBet.odds;
    
    const backProfit = backReturn - totalStake;
    const layProfit = bet.layBet.stake - bet.layBet.liability;
    
    return {
      totalStake,
      minProfit: Math.min(backProfit, layProfit),
      maxProfit: Math.max(backProfit, layProfit),
      isMiddle: false,
      isValueBet: false,
    };
  }
  
  return { totalStake: 0, minProfit: 0, maxProfit: 0, isMiddle: false, isValueBet: false };
}

function BetRow({
  bet,
  onUpdate,
  onDelete,
}: {
  bet: PlacedBet;
  onUpdate: (updates: Partial<PlacedBet>) => void;
  onDelete: () => void;
}) {
  const [isEditingProfit, setIsEditingProfit] = useState(false);
  const [manualProfit, setManualProfit] = useState(bet.actualProfit?.toString() || '');

  const outcomes = getBetOutcomes(bet);
  const { totalStake, minProfit, maxProfit, isMiddle, isValueBet, middleProfit } = calculateBetProfits(bet);
  const is3Way = bet.mode === 'book-vs-book' && bet.bet3;
  
  const eventPast = isEventPast(bet.event.commenceTime);
  const eventSoon = isEventSoon(bet.event.commenceTime);

  const handleOutcomeSelect = (outcomeId: string) => {
    if (outcomeId === 'pending') {
      onUpdate({ status: 'pending', actualProfit: undefined });
    } else if (outcomeId === 'manual') {
      setIsEditingProfit(true);
    } else {
      const selectedOutcome = outcomes.find(o => o.id === outcomeId);
      if (selectedOutcome) {
        let status: PlacedBet['status'] = 'won';
        if (outcomeId === 'middle_hit') {
          status = 'middle-hit';
        } else if (isMiddle && outcomeId !== 'middle_hit') {
          status = 'middle-miss';
        } else if (selectedOutcome.profit < 0) {
          status = 'lost';
        }
        onUpdate({ 
          status,
          actualProfit: selectedOutcome.profit 
        });
      }
    }
  };

  const handleManualProfitSave = () => {
    const profit = parseFloat(manualProfit);
    if (!isNaN(profit)) {
      onUpdate({ status: 'partial', actualProfit: profit });
    }
    setIsEditingProfit(false);
  };

  // Determine current selection
  const getCurrentOutcomeId = (): string => {
    if (bet.status === 'pending') return 'pending';
    if (bet.status === 'partial') return 'manual';
    
    if (bet.actualProfit !== undefined) {
      const matching = outcomes.find(o => Math.abs(o.profit - bet.actualProfit!) < 0.01);
      if (matching) return matching.id;
    }
    
    return 'pending';
  };

  return (
    <div 
      className="px-3 sm:px-6 py-3 sm:py-4 hover:bg-[var(--surface-hover)] transition-colors"
      style={{ borderColor: 'var(--border)' }}
    >
      {/* Mobile Layout: Stack vertically */}
      <div className="flex flex-col gap-3">
        {/* Row 1: Event Title + Mode Badge + Delete (mobile: title truncates, delete on right) */}
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1 min-w-0">
            {/* Event Title */}
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-medium text-sm sm:text-base truncate" style={{ color: 'var(--foreground)' }}>
                {bet.event.homeTeam} vs {bet.event.awayTeam}
              </span>
            </div>
            {/* Badges */}
            <div className="flex items-center gap-1.5 mt-1">
              <ModeBadge mode={bet.mode} />
              {is3Way && (
                <span 
                  className="text-[10px] sm:text-xs px-1.5 py-0.5 rounded"
                  style={{
                    backgroundColor: 'var(--surface-secondary)',
                    color: 'var(--muted)'
                  }}
                >
                  3-way
                </span>
              )}
            </div>
          </div>
          
          {/* Delete button - always visible on right */}
          <button
            onClick={onDelete}
            className="p-1.5 transition-colors shrink-0"
            style={{ color: 'var(--muted)' }}
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>

        {/* Row 2: Event Time & Placed Time */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3 text-xs">
          <div 
            className={`flex items-center gap-1 ${eventSoon ? 'text-yellow-500' : ''}`}
            style={!eventPast && !eventSoon ? { color: 'var(--muted)' } : eventPast ? { color: 'var(--muted)' } : {}}
          >
            <Clock className="w-3 h-3 shrink-0" />
            <span className="sm:hidden">{formatEventTimeShort(bet.event.commenceTime)}</span>
            <span className="hidden sm:inline">{formatEventTime(bet.event.commenceTime)}</span>
            {eventPast && <span style={{ color: 'var(--muted-foreground)' }}>(finished)</span>}
            {eventSoon && <span className="text-yellow-500">(soon!)</span>}
          </div>
          <div className="flex items-center gap-1" style={{ color: 'var(--muted-foreground)' }}>
            <Calendar className="w-3 h-3 shrink-0" />
            <span>Placed {format(new Date(bet.createdAt), 'MMM d, h:mm a')}</span>
          </div>
        </div>
        
        {/* Row 3: Individual Bets - Stacked on mobile */}
        <div className="text-xs space-y-1.5">
          {/* Value Bet */}
          {bet.mode === 'value-bet' && bet.bet1 && (
            <BetLine 
              stake={bet.bet1.stake} 
              outcome={bet.bet1.outcome} 
              odds={bet.bet1.odds} 
              bookmaker={bet.bet1.bookmaker} 
            />
          )}
          
          {/* Spread/Totals/Middle/Book-vs-Book */}
          {(bet.mode === 'book-vs-book' || bet.mode === 'spread' || bet.mode === 'totals' || bet.mode === 'middle') && bet.bet1 && bet.bet2 && (
            <>
              <BetLine 
                stake={bet.bet1.stake} 
                outcome={bet.bet1.outcome} 
                odds={bet.bet1.odds} 
                bookmaker={bet.bet1.bookmaker}
                point={bet.bet1.point}
              />
              <BetLine 
                stake={bet.bet2.stake} 
                outcome={bet.bet2.outcome} 
                odds={bet.bet2.odds} 
                bookmaker={bet.bet2.bookmaker}
                point={bet.bet2.point}
              />
              {bet.bet3 && (
                <BetLine 
                  stake={bet.bet3.stake} 
                  outcome={bet.bet3.outcome} 
                  odds={bet.bet3.odds} 
                  bookmaker={bet.bet3.bookmaker} 
                />
              )}
            </>
          )}
          
          {/* Book vs Betfair */}
          {bet.mode === 'book-vs-betfair' && bet.backBet && bet.layBet && (
            <>
              <BetLine 
                stake={bet.backBet.stake} 
                outcome={bet.backBet.outcome} 
                odds={bet.backBet.odds} 
                bookmaker={bet.backBet.bookmaker}
                prefix="Back"
              />
              <div className="flex flex-col sm:flex-row sm:justify-between gap-0.5" style={{ color: 'var(--muted)' }}>
                <span>
                  Lay ${bet.layBet.stake.toFixed(2)} @ {bet.layBet.odds} (liability: ${bet.layBet.liability.toFixed(2)})
                </span>
                <span style={{ color: 'var(--muted)' }}>
                  Return: ${(bet.layBet.stake + bet.layBet.liability).toFixed(2)}
                </span>
              </div>
            </>
          )}

          {/* Middle Range */}
          {bet.mode === 'middle' && bet.middleRange && (
            <div className="text-yellow-400 mt-1">
              🎯 {bet.middleRange.description}
            </div>
          )}
        </div>

        {/* Row 4: Summary Line */}
        <div 
          className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs pt-2 border-t"
          style={{ borderColor: 'var(--border-light)' }}
        >
          <span style={{ color: 'var(--muted-foreground)' }}>
            Total: ${totalStake.toFixed(2)}
          </span>
          {isValueBet ? (
            <span className="text-blue-400">
              EV: +${bet.expectedProfit.toFixed(2)} · Win: +${maxProfit.toFixed(2)}
            </span>
          ) : isMiddle ? (
            <span className="text-yellow-400">
              Middle: +${middleProfit?.toFixed(2)} · Miss: ${minProfit.toFixed(2)}
            </span>
          ) : (
            <span className={`font-medium ${minProfit >= 0 ? 'text-green-500' : 'text-red-400'}`}>
              {Math.abs(maxProfit - minProfit) > 0.01 ? (
                <>Profit: ${minProfit.toFixed(2)} – ${maxProfit.toFixed(2)}</>
              ) : (
                <>Guaranteed: {minProfit >= 0 ? '+' : ''}${minProfit.toFixed(2)}</>
              )}
            </span>
          )}
        </div>

        {/* Row 5: Controls - Full width on mobile */}
        <div className="flex items-center gap-2 sm:gap-3 pt-1">
          {/* Outcome Selector */}
          <select
            value={getCurrentOutcomeId()}
            onChange={e => handleOutcomeSelect(e.target.value)}
            className="flex-1 sm:flex-none text-xs px-2 py-1.5 focus:outline-none rounded min-w-0 sm:max-w-[160px]"
            style={{
              backgroundColor: 'var(--surface-secondary)',
              borderColor: 'var(--border)',
              color: 'var(--foreground)'
            }}
          >
            <option value="pending">Pending</option>
            <optgroup label="Select Outcome">
              {outcomes.map(outcome => (
                <option key={outcome.id} value={outcome.id}>
                  {outcome.label} ({outcome.profit >= 0 ? '+' : ''}${outcome.profit.toFixed(2)})
                </option>
              ))}
            </optgroup>
            <option value="manual">Manual entry...</option>
          </select>

          {/* Actual Profit Display / Edit */}
          <div className="shrink-0">
            {bet.status === 'pending' ? (
              <div className="text-xs px-2 py-1" style={{ color: 'var(--muted)' }}>
                Exp: ${bet.expectedProfit.toFixed(2)}
              </div>
            ) : isEditingProfit || getCurrentOutcomeId() === 'manual' ? (
              <div className="flex gap-1">
                <input
                  type="number"
                  value={manualProfit}
                  onChange={e => setManualProfit(e.target.value)}
                  className="w-20 text-xs px-2 py-1.5 font-mono focus:outline-none rounded"
                  style={{
                    backgroundColor: 'var(--surface-secondary)',
                    borderColor: 'var(--border)',
                    color: 'var(--foreground)'
                  }}
                  placeholder="0.00"
                  autoFocus
                  onBlur={handleManualProfitSave}
                  onKeyDown={e => e.key === 'Enter' && handleManualProfitSave()}
                />
              </div>
            ) : (
              <button
                onClick={() => {
                  setManualProfit(bet.actualProfit?.toString() || '');
                  setIsEditingProfit(true);
                }}
                className="text-xs font-mono px-2 py-1 transition-colors rounded hover:bg-[var(--surface-secondary)]"
                title="Click to edit manually"
              >
                {bet.actualProfit !== undefined ? (
                  <span className={bet.actualProfit >= 0 ? 'text-green-400' : 'text-red-400'}>
                    {bet.actualProfit >= 0 ? '+' : ''}${bet.actualProfit.toFixed(2)}
                  </span>
                ) : (
                  <span style={{ color: 'var(--muted)' }}>Set profit</span>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Individual bet line with return calculation - Mobile optimized
function BetLine({ 
  stake, 
  outcome, 
  odds, 
  bookmaker,
  prefix,
  point,
}: { 
  stake: number; 
  outcome: string; 
  odds: number; 
  bookmaker: string;
  prefix?: string;
  point?: number;
}) {
  const returnAmount = stake * odds;
  
  return (
    <div className="flex flex-col sm:flex-row sm:justify-between gap-0.5" style={{ color: 'var(--muted)' }}>
      <span className="break-words">
        {prefix && <span style={{ color: 'var(--muted)' }}>{prefix} </span>}
        ${stake.toFixed(2)} on {outcome}
        {point !== undefined && <span style={{ color: 'var(--muted)' }}> ({point > 0 ? '+' : ''}{point})</span>}
        {' '}@ {odds.toFixed(2)} ({bookmaker})
      </span>
      <span className="sm:ml-4 whitespace-nowrap" style={{ color: 'var(--muted)' }}>
        Return: ${returnAmount.toFixed(2)}
      </span>
    </div>
  );
}
