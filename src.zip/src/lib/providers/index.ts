// src/lib/providers/index.ts
export { TheOddsApiProvider, createOddsApiProvider } from './theOddsApiProvider';
export type { OddsProvider, ProviderResult, Sport } from './types';